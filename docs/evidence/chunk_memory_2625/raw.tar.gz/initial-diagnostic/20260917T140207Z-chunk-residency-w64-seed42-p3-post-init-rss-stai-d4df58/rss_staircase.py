"""One production headless RSS diagnostic; all samples and failures retained."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import socket
import statistics
import subprocess
import threading
import time

OUT = Path(os.environ['CODEX_PROFILE_ARTIFACT_DIR'])
ROOT = Path.cwd()
EXE = ROOT / 'dist-newstyle/build/aarch64-osx/ghc-9.12.2/synarchy-0.1.0.0/build/synarchy/synarchy'

def command(argv):
    p = subprocess.run(argv, capture_output=True, text=True, timeout=15)
    return {'argv': argv, 'exit_code': p.returncode, 'stdout': p.stdout, 'stderr': p.stderr}

def console(port, code, timeout=15):
    with socket.create_connection(('127.0.0.1', port), timeout=5) as s:
        s.settimeout(timeout)
        s.sendall((code + '\n').encode())
        s.shutdown(socket.SHUT_WR)
        parts = []
        while True:
            part = s.recv(65536)
            if not part:
                break
            parts.append(part)
    raw = b''.join(parts).decode().strip()
    with (OUT/'console.jsonl').open('a') as transcript:
        transcript.write(json.dumps({'command': code, 'raw_response': raw})+'\n')
    lines = [line.removeprefix('> ').strip() for line in raw.splitlines()
             if line.strip() not in ('synarchy debug console', '>')]
    value = '\n'.join(lines).strip()
    if value.startswith(('error:', 'syntax error:')):
        raise RuntimeError(value)
    return value

def coords(radius):
    result = set()
    for x in range(-radius, radius + 1):
        for y in range(-radius, radius + 1):
            u, v = (x-y+32) % 64 - 32, x+y
            result.add(((u+v)//2, (v-u)//2))
    return sorted(result)

def verify(port, radius):
    pairs = ','.join('{%d,%d}' % c for c in coords(radius))
    code = ('local n=0; local missing={}; for _,c in ipairs({' + pairs +
            '}) do local r=world.getChunkInfo(c[1],c[2]); '
            'if r and r.loaded then n=n+1 else missing[#missing+1]=c end end; '
            'return {loaded=n,missing=missing}')
    return json.loads(console(port, code, 30))

def sample(index):
    directory = OUT / f'sample-{index}'
    directory.mkdir()
    resource = directory / 'resources'
    resource.mkdir()
    for family in ('assets', 'data', 'scripts'):
        (resource / family).symlink_to(ROOT / family, target_is_directory=True)
    shutil.copytree(ROOT / 'config', resource / 'config',
                    ignore=shutil.ignore_patterns('*.local.yaml'))
    with socket.socket() as s:
        s.bind(('127.0.0.1', 0))
        port = s.getsockname()[1]
    assert port != 8008
    env = os.environ.copy()
    for key in ('GHCRTS', 'ENGINE_DEBUG', 'SYNARCHY_ROOT', 'SYNARCHY_FULL_TESTS'):
        env.pop(key, None)
    env['LC_ALL'] = 'C'
    argv = [str(EXE), '--headless', '--port', str(port), '--resource-root', str(resource)]
    result = {'sample': index, 'argv': argv, 'stages': [], 'loadavg_before': os.getloadavg()}
    timeline = []
    phase = ['boot']
    stop = threading.Event()
    started = time.monotonic()
    process = None
    monitor = None
    log = directory / 'engine.log'
    def observe():
        while not stop.is_set():
            p = subprocess.run(['/bin/ps', '-p', str(process.pid), '-o', 'rss='],
                               capture_output=True, text=True, timeout=5)
            if p.returncode == 0 and p.stdout.strip():
                timeline.append({'seconds': time.monotonic()-started,
                                 'phase': phase[0], 'rss_bytes': int(p.stdout.strip())*1024})
            stop.wait(0.25)
    try:
        with log.open('w') as stream:
            process = subprocess.Popen(argv, stdout=stream, stderr=subprocess.STDOUT, env=env)
            result['pid'] = process.pid
            monitor = threading.Thread(target=observe)
            monitor.start()
            deadline = time.monotonic()+60
            while 'READY port=' not in log.read_text(errors='replace'):
                if process.poll() is not None or time.monotonic() > deadline:
                    raise RuntimeError('engine did not become ready')
                time.sleep(0.1)
            phase[0] = 'world-init'
            result['init_response'] = console(port, 'world.init("rss_world",42,64,3)')
            result['init_wait'] = console(port, 'return world.waitForInit(300)', 310)
            if 'done' not in result['init_wait'].lower():
                raise RuntimeError('world initialization incomplete')
            console(port, 'world.show("rss_world"); engine.setPaused(true)')
            deadline = time.monotonic()+15
            while 'rss_world' not in console(port, 'return world.getActiveWorldId()'):
                if time.monotonic() > deadline:
                    raise RuntimeError('page did not become active')
                time.sleep(0.1)
            for radius in (2, 8, 16):
                phase[0] = f'load-r{radius}'
                stage = {'radius': radius, 'expected_unique_requested': len(coords(radius))}
                result['stages'].append(stage)
                stage['queued'] = console(port, f'return world.loadChunksInRegion({-radius},{-radius},{radius},{radius},"rss_world")')
                stage['remaining'] = console(port, 'return world.waitForChunks(180,"rss_world")', 190)
                if stage['remaining'] != '0':
                    raise RuntimeError('chunk queue did not drain')
                deadline = time.monotonic()+15
                while True:
                    check = verify(port, radius)
                    stage['before'] = check
                    if check['loaded'] == stage['expected_unique_requested']:
                        break
                    if time.monotonic() > deadline:
                        raise RuntimeError(f'requested chunks not resident: {check}')
                    time.sleep(0.25)
                phase[0] = f'dwell-r{radius}'
                time.sleep(8)
                phase[0] = f'verify-r{radius}'
                stage['after'] = verify(port, radius)
                if stage['after']['loaded'] != stage['expected_unique_requested']:
                    raise RuntimeError('requested resident set changed during dwell')
                values = [row['rss_bytes'] for row in timeline if row['phase'] == f'dwell-r{radius}']
                if len(values) < 20:
                    raise RuntimeError('insufficient RSS samples')
                stage['rss'] = {'n': len(values), 'min': min(values), 'median': statistics.median(values), 'max': max(values)}
                print(json.dumps({'sample': index, 'radius': radius, 'rss': stage['rss']}), flush=True)
            phase[0] = 'shutdown'
            result['quit'] = console(port, 'engine.quit()')
            result['exit_code'] = process.wait(timeout=60)
            if result['exit_code'] != 0:
                raise RuntimeError('engine exited unsuccessfully')
            result['status'] = 'passed'
    except BaseException as exc:
        result['status'] = 'failed'
        result['error'] = repr(exc)
        raise
    finally:
        if process is not None and process.poll() is None:
            try:
                console(port, 'engine.quit()', 3)
                process.wait(timeout=15)
            except Exception:
                process.terminate()
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=10)
        stop.set()
        if monitor is not None:
            monitor.join(timeout=10)
        result['elapsed_seconds'] = time.monotonic()-started
        result['loadavg_after'] = os.getloadavg()
        (directory/'timeline.json').write_text(json.dumps(timeline, indent=2))
        (directory/'result.json').write_text(json.dumps(result, indent=2))

if __name__ == '__main__':
    metadata = {'revision': os.environ['CODEX_PROFILE_REVISION'],
                'executable_sha256': hashlib.sha256(EXE.read_bytes()).hexdigest(),
                'method': 'production baked -N -A128M; no explicit RTS override; 3 fresh processes; r2/r8/r16 sequential; 8s dwell; ps RSS at nominal 250ms; no forced GC',
                'environment': [command(a) for a in [
                    ['sw_vers'], ['sysctl', '-n', 'hw.model', 'hw.memsize', 'hw.physicalcpu', 'machdep.cpu.brand_string'],
                    ['ghc', '--version'], ['cabal', '--version'], ['pmset', '-g', 'batt'], ['pmset', '-g', 'therm']]]}
    (OUT/'metadata.json').write_text(json.dumps(metadata, indent=2))
    for i in range(1,4):
        sample(i)
